// src/services/index.ts - Main service exports
export { googleService } from './google.service';
export { emailService } from './email.service';
export { gdprService } from './gdpr.service';
export { registrationService } from './registration.service';